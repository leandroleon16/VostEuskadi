const { Client } = require('pg');

// Configuración de la conexión a PostgreSQL
const dbConfig = {
  user: 'postgres',
  host: 'localhost',
  database: 'vostbd',
  password: '123456',
  port: 5432, // Puerto predeterminado de PostgreSQL
};

// Crear un cliente PostgreSQL
const client = new Client(dbConfig);

// Conectar al servidor PostgreSQL
client.connect()
  .then(() => {
    console.log('Conexión exitosa a PostgreSQL');

    // Sentencia SQL para crear la tabla
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS estado_puertos (
        id SERIAL PRIMARY KEY,
        puerto VARCHAR(255),
        territorio_historico VARCHAR(255),
        t VARCHAR(50),
        c VARCHAR(50),
        a VARCHAR(50),
        ultima_actualizacion TIMESTAMP,
        red VARCHAR(50),
        carretera VARCHAR(255),
        situacion VARCHAR(255),
        fuente VARCHAR(255)
      );
    `;

    // Ejecutar la sentencia SQL
    return client.query(createTableQuery);
  })
  .then(() => {
    console.log('Tabla creada exitosamente');
  })
  .catch((error) => {
    console.error('Error al conectar o crear la tabla:', error);
  })
  .finally(() => {
    // Cerrar la conexión
    client.end();
  });
