const axios = require('axios');
const cheerio = require('cheerio');
const { Client } = require('pg');
const cron = require('node-cron');
const { IncomingWebhook } = require('@slack/webhook');


// Configuración de la base de datos PostgreSQL
const pgClient = new Client({
  user: 'postgres',
  host: 'localhost',
  database: 'vostbd',
  password: '123456',
  port: 5432, // Puerto predeterminado de PostgreSQL
});
pgClient.connect();

// Configuración del Webhook de Slack
const slackWebhookUrl = 'https://hooks.slack.com/services/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';
const slack = new IncomingWebhook(slackWebhookUrl);

// Función para extraer datos del sitio de tráfico de Euskadi
async function extraerDatosTraficoEuskadi() {
  const response = await axios.get('https://www.trafikoa.euskadi.eus/wps/portal/trafico/vialidadInvernal');
  const body = response.data;

  // Utilizar Cheerio para analizar el HTML y extraer la información necesaria
  const $ = cheerio.load(body);

  // Seleccionar la tabla de interés (1. Puertos CAPV y Nafarroa)
  const tablaPuertos = $('caption:contains("1. Puertos CAPV y Nafarroa")').closest('table');

  // Inicializar un array para almacenar los datos de la tabla
  const datosTabla = [];

  // Iterar sobre las filas de la tabla, excluyendo la primera (encabezados)
  tablaPuertos.find('tbody tr:gt(0)').each((index, row) => {
    const $row = $(row);

    // Extraer datos de las celdas de la fila
    const puerto = $row.find('td:nth-child(1)').text().trim();
    const territorioHistorico = $row.find('td:nth-child(2)').text().trim();
    const t = $row.find('td:nth-child(3) img').attr('title');
    const c = $row.find('td:nth-child(4) img').attr('title');
    const a = $row.find('td:nth-child(5) img').attr('title');
    const ultimaActualizacion = $row.find('td:nth-child(6)').text().trim();
    const red = $row.find('td:nth-child(7)').text().trim();
    const carretera = $row.find('td:nth-child(8)').text().trim();
    const situacion = $row.find('td:nth-child(9)').text().trim();
    const fuente = $row.find('td:nth-child(10)').text().trim();

    // Agregar los datos al array
    datosTabla.push({
      puerto,
      territorioHistorico,
      t,
      c,
      a,
      ultimaActualizacion,
      red,
      carretera,
      situacion,
      fuente,
    });
  });

  return datosTabla;
}

// Función para almacenar datos en PostgreSQL
async function almacenarDatosEnBD(datosTabla) {
  // Conectar con la base de datos
  try {
    // Iterar sobre los datos y ejecuta una inserción para cada registro
    for (const datosPuerto of datosTabla) {
      await pgClient.query(
        `INSERT INTO estado_puertos 
        (puerto, territorio_historico, t, c, a, ultima_actualizacion, red, carretera, situacion, fuente) 
        VALUES 
        ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [
          datosPuerto.puerto,
          datosPuerto.territorioHistorico,
          datosPuerto.t,
          datosPuerto.c,
          datosPuerto.a,
          datosPuerto.ultimaActualizacion,
          datosPuerto.red,
          datosPuerto.carretera,
          datosPuerto.situacion,
          datosPuerto.fuente,
        ]
      );
    }

    console.log('Datos almacenados en la base de datos.');
  } catch (error) {
    console.error('Error al insertar datos en la base de datos:', error);
  }
}
// Función para enviar notificación a Slack en caso de variación
async function enviarNotificacionSlack(datosPuertos) {
    try {
      // Mensaje de prueba
      const mensajePrueba = 'Esto es un mensaje de prueba desde el scraper. ¡Funciona!';
  
      // Enviar el mensaje de prueba a Slack
      await slack.send({
        text: mensajePrueba,
      });
  
      console.log('Mensaje de prueba enviado a Slack.');
    } catch (error) {
      console.error('Error al enviar mensaje de prueba a Slack:', error);
      throw error;
    }
  }
// Tarea cron para ejecutar el scraper cada minuto
cron.schedule('0 * * * *', async () => {
  console.log('Iniciando scraper...');

  try {
    const datosPuertos = await extraerDatosTraficoEuskadi();
    await almacenarDatosEnBD(datosPuertos);

    console.log('Scraper completado.');
  } catch (error) {
    console.error('Error durante la ejecución del scraper:', error);
  }
});

// Mantener la aplicación en ejecución
process.stdin.resume();

// Manejar cierre de la aplicación
process.on('exit', () => {
  console.log('Cerrando conexión a la base de datos.');
  pgClient.end();
});
